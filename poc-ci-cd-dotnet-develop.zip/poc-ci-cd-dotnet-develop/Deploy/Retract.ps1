﻿$snapin = get-pssnapin | ? { $_.name -eq "Microsoft.sharepoint.powershell"} 
if($snapin -eq $null) { add-pssnapin Microsoft.SharePoint.Powershell }

$global:ErrorActionPreference = "Stop"

$pathInstall = split-path (Resolve-path $MyInvocation.MyCommand.Definition)
$farm = Get-SPFarm
$Environnement = $farm.Properties["ENV_NAME"]
function CheckAndStartAppPoolsAndWebSites()
{
    Process
    {       
        $list=@("WebFrontEnd","Application","WebFrontEndWithDistributedCache","ApplicationWithSearch","SingleServerFarm","Custom")
        $servers = Get-SPServer
        foreach($server in $servers)
        {
    
            if($list -Contains $($server.Role))
            {    
                Write-Host "Serveur Sharepoint:$($server.Name)"                

                Invoke-Command -ComputerName $($server.Address) -ScriptBlock {
                    param($siteUrl)
                    Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue                   
                    $webApp = Get-SPWebApplication
                    $appPool=$webApp.ApplicationPool
            
                    $status=Get-WebAppPoolState -Name $($appPool.Name)            

                    if($status.Value -ne "Started"){
                        Start-WebAppPool -Name $($appPool.Name)
                        Write-Host "Démarrage de l'application pool $($appPool.Name)"
                    }
                    $iisSite=$webApp.IisSettings.Item("Default")
                    if($iisSite -ne $null)
                    {               
                             
                        $siteInfo=Get-Website | Where physicalPath -eq $($iisSite.Path)
                
                        if($siteInfo -ne $null)
                        {
                            if($siteInfo.State -ne "Started")
                            {
                                Start-WebSite -Name $($siteInfo.Name)
                                Write-Host "Démarrage du site iis $($siteInfo.Name)"
                            }
                        }
                    }
                } 
            }
            
        }
    }
}
function RetractAndDisableFeature($siteUrl)
{
	$featureActivated = Get-SPFeature -Identity "CATS.CDOC.SimpleTestGITGroupe_Branding" -Site $siteUrl -ErrorAction SilentlyContinue
  
	if($featureActivated -ne $null)
	{
        
		#Activate the feature
		Disable-SPFeature -Identity $featureActivated -URL $siteUrl -Confirm:$False
        Write-Host "Disable Feature on "$siteUrl
    }
	else
	{
		Write-Host "Feature not activated at: "$siteUrl
		
	}
	$sol=Get-SPSolution -Identity "CATS.CDOC.SimpleTestGITGroupe.wsp" -ErrorAction SilentlyContinue
    if($sol -ne $null)
    {	
        $webApp = Get-SPWebApplication	
		Uninstall-SPSolution -Identity "CATS.CDOC.SimpleTestGITGroupe.wsp" -WebApplication $webApp -Confirm:$false        
        $Solution = get-SpSolution "CATS.CDOC.SimpleTestGITGroupe.wsp"
        while($Solution.JobExists)
        {
            sleep 5
            Write-Host -NoNewline "."
            $Solution = get-SpSolution "CATS.CDOC.SimpleTestGITGroupe.wsp"
        }
        Write-Host ""
		Remove-SPSolution "CATS.CDOC.SimpleTestGITGroupe.wsp" -Confirm:$false
        Write-Host "Solution removed"
    }
	CheckAndStartAppPoolsAndWebSites	
	
}

switch($Environnement)
{
	"DevTU_2T"{		
		RetractAndDisableFeature("https://cdoc-wfe-1.collab.ca-devtu-zad0.ca-technologies.credit-agricole.fr")
	}
	"DevTU_2V"{
		RetractAndDisableFeature("https://cdoc-wfe-2.collab.ca-devtu-zad0.ca-technologies.credit-agricole.fr")
	}
	"VMOA"{
		RetractAndDisableFeature("https://cdoc-wfe.collab.ca-vmoa-zaua0.ca-technologies.credit-agricole.fr")
	}
	"NEHOM"{
		RetractAndDisableFeature("https://cdoc-wfe.collab.ca-nehom-zur10.credit-agricole.fr")
	}
}
