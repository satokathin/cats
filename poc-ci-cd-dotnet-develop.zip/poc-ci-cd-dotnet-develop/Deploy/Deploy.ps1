﻿$snapin = get-pssnapin | ? { $_.name -eq "Microsoft.sharepoint.powershell"} 
if($snapin -eq $null) { add-pssnapin Microsoft.SharePoint.Powershell }

$global:ErrorActionPreference = "Stop"

$pathInstall = split-path (Resolve-path $MyInvocation.MyCommand.Definition)
$farm = Get-SPFarm
$Environnement = $farm.Properties["ENV_NAME"]

function CheckAndStartAppPoolsAndWebSites()
{
    Process
    {       
        $list=@("WebFrontEnd","Application","WebFrontEndWithDistributedCache","ApplicationWithSearch","SingleServerFarm","Custom")
        $servers = Get-SPServer
        foreach($server in $servers)
        {
    
            if($list -Contains $($server.Role))
            {    
                Write-Host "Serveur Sharepoint:$($server.Name)"                

                Invoke-Command -ComputerName $($server.Address) -ScriptBlock {
                    param($siteUrl)
                    Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue                   
                    $webApp = Get-SPWebApplication
                    $appPool=$webApp.ApplicationPool
            
                    $status=Get-WebAppPoolState -Name $($appPool.Name)            

                    if($status.Value -ne "Started"){
                        Start-WebAppPool -Name $($appPool.Name)
                        Write-Host "Démarrage de l'application pool $($appPool.Name)"
                    }
                    $iisSite=$webApp.IisSettings.Item("Default")
                    if($iisSite -ne $null)
                    {               
                             
                        $siteInfo=Get-Website | Where physicalPath -eq $($iisSite.Path)
                
                        if($siteInfo -ne $null)
                        {
                            if($siteInfo.State -ne "Started")
                            {
                                Start-WebSite -Name $($siteInfo.Name)
                                Write-Host "Démarrage du site iis $($siteInfo.Name)"
                            }
                        }
                    }
                } 
            }
            
        }
    }
}

function DeployAndActivateFeature($siteUrl)
{
	$webApp = Get-SPWebApplication
    Add-SPSolution -LiteralPath "$pathInstall\CATS.CDOC.SimpleTestGITGroupe.wsp"
	Install-SPSolution –Identity "CATS.CDOC.SimpleTestGITGroupe.wsp" -WebApplication $webApp -GACDeployment
	CheckAndStartAppPoolsAndWebSites
    $Solution = get-SpSolution "CATS.CDOC.SimpleTestGITGroupe.wsp"
    while($Solution.JobExists)
    {
        sleep 5
        Write-Host -NoNewline "."
        $Solution = get-SpSolution "CATS.CDOC.SimpleTestGITGroupe.wsp"
    }
    Write-Host ""
	$featureActivated = Get-SPFeature -Identity "CATS.CDOC.SimpleTestGITGroupe_Branding" -Site $siteUrl -ErrorAction SilentlyContinue
  
	if($featureActivated -ne $null)
	{
		Write-Host "Feature already activated at: "$siteUrl
	}
	else
	{
		#Activate the feature
		Enable-SPFeature -Identity "CATS.CDOC.SimpleTestGITGroupe_Branding" -URL $siteUrl -Confirm:$False
		Write-Host "Activated Feature on "$siteUrl
	}
}

switch($Environnement)
{
	"DevTU_2T"{
		
		DeployAndActivateFeature("https://cdoc-wfe-1.collab.ca-devtu-zad0.ca-technologies.credit-agricole.fr")
	}
	"DevTU_2V"{
		DeployAndActivateFeature("https://cdoc-wfe-2.collab.ca-devtu-zad0.ca-technologies.credit-agricole.fr")
	}
	"VMOA"{
		DeployAndActivateFeature("https://cdoc-wfe.collab.ca-vmoa-zaua0.ca-technologies.credit-agricole.fr")
	}
	"NEHOM"{
		DeployAndActivateFeature("https://cdoc-wfe.collab.ca-nehom-zur10.credit-agricole.fr/")
	}

}
