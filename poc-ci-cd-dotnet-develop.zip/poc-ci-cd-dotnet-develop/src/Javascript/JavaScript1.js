﻿jQuery(document).ready(function () {
    var stgitgroupElm1 = document.getElementById("stgitgroup");
    stgitgroupElm1.innerHTML = "<span>Test GIT1</span>";
});
