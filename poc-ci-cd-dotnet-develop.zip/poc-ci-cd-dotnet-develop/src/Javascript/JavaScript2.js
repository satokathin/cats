﻿jQuery(document).ready(function () {
    var stgitgroupElm2 = document.getElementById("stgitgroup");
    stgitgroupElm2.innerHTML = "<span>Test GIT1</span><span>Test GIT2</span>";
});