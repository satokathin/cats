﻿
var gulp = require('gulp'),
    gutil = require("gulp-util"),
    concat = require('gulp-concat'),
    cleanCSS = require('gulp-clean-css'),
    del = require('del'),
    minify = require('gulp-minify'),
    cssnano = require('gulp-cssnano');

const { series, parallel } = require('gulp');

const envtask = (cb) => {    
    var env = gutil.env.mode || 'default';
    console.log('This is ' + env + " environment");
    cb();
};

const bundleJsCDOC = (cb) => {
    /*cdoc master*/
    gulp.src([
        "./Javascript/Javascript1.js",
        "./Javascript/Javascript2.js"
    ])
        .pipe(concat('stgitgroup.js'))
        .pipe(gutil.env.mode === 'Release' ? minify() : gutil.noop())
        .pipe(gulp.dest('tmp'))
        .on('end', cb);
}

const minifyJsCDOC = (cb) => {
    /*cdoc master*/
    gulp.src([
        gutil.env.mode === 'Release' ? "tmp/stgitgroup-min.js" : "tmp/stgitgroup.js"

    ])
        .pipe(concat('stgitgroup.js'))
        .pipe(gulp.dest('./Modules/GITGroupeTestPage/'))
        .on('end', cb);
};


const bundleJs = parallel(bundleJsCDOC);
const minifyJs = parallel(minifyJsCDOC);


const fakeProdNoCleanup = function () {
    gutil.env.mode = "Release";
    return series(envtask,
        parallel(series(bundleJs, minifyJs)));
};

exports.default = series(envtask, parallel(series(bundleJs, minifyJs)));