﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace CATS.CDOC.SimpleTestGITGroupe
{
    /// <summary>
    /// Page d'accueil CR
    /// </summary>
    public partial class TestPageGITModule : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
