using Microsoft.SharePoint;
using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;

namespace CATS.CDOC.SimpleTestGITGroupe.Features.Branding
{
    /// <summary>
    /// Cette classe gère les événements déclenchés lors de l'activation, la désactivation, l'installation, la désinstallation et la mise à niveau de fonctions.
    /// </summary>
    /// <remarks>
    /// Le GUID attaché à cette classe peut être utilisé lors de la compression et ne doit pas être modifié.
    /// </remarks>

    [Guid("6b358ade-da26-4c50-830c-8bc21778d5b1")]
    public class BrandingEventReceiver : SPFeatureReceiver
    {
               


        // Supprimez les marques de commentaire de la méthode ci-dessous pour gérer l'événement déclenché avant la désactivation d'une fonction.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSite site = properties.Feature.Parent as SPSite;            
            SPFile file=site.RootWeb.GetFile("Style Library/GITGroupeTestPage/stgitgroup.js");
            if(file != null)
            { 
                file.Delete();
            }
            SPFile file2 = site.RootWeb.GetFile("Pages/TestPageGITModule.aspx");
            if (file2 != null)
            {
                file2.Delete();
            }

        }


        // Supprimez les marques de commentaire de la méthode ci-dessous pour gérer l'événement déclenché après l'installation d'une fonction.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Supprimez les marques de commentaire de la méthode ci-dessous pour gérer l'événement déclenché avant la désinstallation d'une fonction.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Supprimez les marques de commentaire de la méthode ci-dessous pour gérer l'événement déclenché lors de la mise à niveau d'une fonction.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
